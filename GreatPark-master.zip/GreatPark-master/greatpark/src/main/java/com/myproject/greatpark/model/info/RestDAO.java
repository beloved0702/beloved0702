package com.myproject.greatpark.model.info;

import java.util.List;

public interface RestDAO {
	List<RestDTO> list();
}
